package com.bdu.clearance.services;

import com.bdu.clearance.models.Student;

import java.util.List;


public interface StudentService {
    List<Student> getAllStudent();
    void createStudent(Student student);
    String deleteStudent(String studentId);
    Student updateStudent(Student student,String studentId);

    List<Student> getStudent(String studentId);
    List<Student> getStudentByFaculty();
    List<Student> getStudentByDepartment();
    List<Student> getStudentByAdvisor();










}
