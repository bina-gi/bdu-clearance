package com.bdu.clearance.services;

import com.bdu.clearance.models.Clearance;
import com.bdu.clearance.models.Student;
import com.bdu.clearance.repositories.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

public class StudentServiceImpl implements StudentService{

    private Long nextId=1L;
    @Autowired
    private StudentRepository studentRepository;



    @Override
    public List<Student> getAllStudent() {
        return studentRepository.findAll();
    }

    @Override
    public void createStudent(Student student) {
        student.setId(nextId);
        studentRepository.save(student);
    }

    @Override
    public String deleteStudent(String studentId) {
        List<Student> allStudents=studentRepository.findAll();
        Student student=allStudents.stream().filter(s->s.getStudentId().equals(studentId))
                .findFirst()
                .orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Student with id:"+studentId+" not found"));
        studentRepository.delete(student);
        return "Clearance with ID: "+ studentId +" deleted Successfully!";
    }

    @Override
    public Student updateStudent(Student student,String studentId) {
        List<Student> allStudents=studentRepository.findAll();

        Optional<Student> optionalStudent=allStudents.stream().filter(s->s.getStudentId().equals(studentId))
                .findFirst();
        if(optionalStudent.isPresent()){
            Student existingStudent=optionalStudent.get();
            existingStudent.setFirstName(student.getFirstName());
            Student savedStudent=studentRepository.save(existingStudent);
            return savedStudent;
        }else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Clearance Not_found" );
        }


    }

    @Override
    public List<Student> getStudent(String studentId) {
        return List.of();
    }

    @Override
    public List<Student> getStudentByFaculty() {
        return List.of();
    }

    @Override
    public List<Student> getStudentByDepartment() {
        return List.of();
    }

    @Override
    public List<Student> getStudentByAdvisor() {
        return List.of();
    }
}
